#include <fsl_device_registers.h>
#include "Util.h"


uint32_t disable_interrupt(void) {
	uint32_t m;
	m = __get_PRIMASK();
	__disable_irq();
	return m;
}

void enable_interrupt(uint32_t m) {
	__set_PRIMASK(m);
}

void init_RGB_LEDS(void) {

  SIM->SCGC5    |= (1 <<  10) | (1 <<  13);  /* Enable Clock to Port B & E */ 
  PORTB->PCR[22] = (1 <<  8) ;               /* Pin PTB22 is GPIO */
  PORTB->PCR[21] = (1 <<  8);                /* Pin PTB21 is GPIO */
  PORTE->PCR[26] = (1 <<  8);                /* Pin PTE26  is GPIO */
  
  PTB->PDOR = (1 << 21 | 1 << 22 );          /* switch Red/Green LED off  */
  PTB->PDDR = (1 << 21 | 1 << 22 );          /* enable PTB18/19 as Output */

  PTE->PDOR = 1 << 26;            /* switch Blue LED off  */
  PTE->PDDR = 1 << 26;            /* enable PTE26 as Output */
}

void RGBLED_Off (void) {	
	// Save and disable interrupts (for atomic LED change)
	uint32_t m = disable_interrupt();
	
  PTB->PSOR   = 1 << 22;   /* Green LED Off*/
  PTB->PSOR   = 1 << 21;   /* Red LED Off*/
  PTE->PSOR   = 1 << 26;   /* Blue LED Off*/
	
	// Restore interrupts
	enable_interrupt(m);
}
void RGBLED_RedToggle(void) {
	PTB->PTOR = 1 << 22;
}
void RGBLED_BlueToggle(void) {
	PTB->PTOR = 1 << 21;
}
void RGBLED_GreenToggle(void){
	PTE->PTOR = 1 << 26; 
}

void delay(void){
	int j;
	for(j=0; j<1000000; j++);
}

void init_LED_matrix(void) {
	
	CLOCK_EnableClock(kCLOCK_PortE);
	CLOCK_EnableClock(kCLOCK_I2c0); // enable i2c clock
	
	PORTE->PCR[24] = PORT_PCR_MUX(0b101);
	PORTE->PCR[25] = PORT_PCR_MUX(0b101);
	
	I2C_EnableInterrupts(I2C0, true);
	I2C_Enable(I2C0,true);
	
	I2C0->C1 |= I2C_C1_IICIE_MASK;
	
	i2c_master_config_t cfg;
	I2C_MasterGetDefaultConfig(&cfg);
	I2C_MasterInit(I2C0,&cfg,DEFAULT_SYSTEM_CLOCK);
	
	uint32_t volatile buffer = 0x00;
	
	i2c_master_transfer_t transfer;
	transfer.flags = kI2C_TransferDefaultFlag;
	transfer.slaveAddress = 0x70;
	transfer.direction = kI2C_Write;
	transfer.data = (uint8_t* volatile) &buffer;
	transfer.subaddress = 0x00;
	transfer.subaddressSize = 0;
	transfer.dataSize = 1;
	
	buffer = 0x21;
	//transfer.subaddressSize = 0;
	transfer.dataSize = 1;
	I2C_MasterTransferBlocking(I2C0,&transfer); // enable oscillation
	
	buffer = 0x81;
	//transfer.subaddressSize = 0;
	transfer.dataSize = 1;
	I2C_MasterTransferBlocking(I2C0,&transfer); // blink rate
	
	buffer = 0xE7;
	//transfer.subaddressSize = 0;
	transfer.dataSize = 1;
	I2C_MasterTransferBlocking(I2C0,&transfer); // set brightness
}

void init_buttons(void) {
	SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK;
	PORTA->PCR[4] = PORT_PCR_MUX(001);
	PTA->PDDR &= ~GPIO_PDDR_PDD(1 << 4);
	PORTA->PCR[4] |= PORT_PCR_IRQC(0b1011);
	NVIC_EnableIRQ(PORTA_IRQn);
	NVIC_SetPriority(PORTA_IRQn, 0);
	
	SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK;
	PORTC->PCR[6] = PORT_PCR_MUX(001);
	PTC->PDDR &= ~GPIO_PDDR_PDD(1 << 6);
	PORTC->PCR[6] |= PORT_PCR_IRQC(0b1011);
	NVIC_EnableIRQ(PORTC_IRQn);
	NVIC_SetPriority(PORTC_IRQn, 0);
}

void init_timer(void) {
	SIM->SCGC6 = SIM_SCGC6_PIT_MASK; // Enable clock to PIT module
	PIT->MCR &= 0xFFFFFFFD;
	PIT->CHANNEL[0].TCTRL |= 3; // enable timer and interrupts
	PIT->CHANNEL[0].LDVAL = DEFAULT_SYSTEM_CLOCK * 0.001; // Set load value of zeroth PIT to 0.001 seconds
	
	PIT->CHANNEL[0].TFLG = 1;
	NVIC_EnableIRQ(PIT0_IRQn); /* enable PIT0 Interrupts (for part 2) */
}

uint8_t volatile matrix[16] = {
	0b11111111, 0b11111111,
	0b11111111, 0b11111111,
	0b11111111, 0b11111111,
	0b11111111, 0b11111111,
	0b11111111, 0b11111111,
	0b11111111, 0b11111111,
	0b11111111, 0b11111111,
	0b11111111, 0b11111111
};
i2c_master_transfer_t redraw_transfer = {
	.flags = kI2C_TransferDefaultFlag,
	.slaveAddress = 0x70,
	.direction = kI2C_Write,
	.data = matrix,
};

void redraw_matrix(void) {
	uint32_t m = disable_interrupt();
	
	redraw_transfer.subaddress = 0x00;
	redraw_transfer.subaddressSize = 1;
	redraw_transfer.dataSize = 16;
	
	I2C_MasterTransferBlocking(I2C0,&redraw_transfer); // set leds on
	
	enable_interrupt(m);
}

void redraw_board(int8_t board[16][8]) {
	for (int i = 0; i < 16; i++) {
		for (int j = 0; j < 8; j++) {
			LED_matrix(i,j, (board[i][j] == 0 ? LED_OFF : LED_ON));
		}
	}
	redraw_matrix();
}

void LED_matrix(int x, int y, int state){
	int index = (2 * (7-y)) + (x / 8);
	int offset = x % 8;
	if (state == LED_ON) {
		matrix[index] = matrix[index] | (1 << offset);
	} else if (state == LED_OFF) {
		matrix[index] = matrix[index] & (~(1 << offset));
	} else if (LED_TOGGLE) {
		matrix[index] = matrix[index] ^ (1 << offset);
	}
}
