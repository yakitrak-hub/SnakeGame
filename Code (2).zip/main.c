#include "util.h"
#include "random.h"

#define STATE_RUNNING 0
#define STATE_ENDED 1

int8_t board[16][8];

int steps = 0;

#define APPLE (-1)
#define EMPTY (0)

#define UP (0)
#define RIGHT (1)
#define DOWN (2)
#define LEFT (3)

int snakeX = 4;
int snakeY = 4;
int snakeLength = 2;
int currDirection = RIGHT;
int nextDirection = RIGHT;

int gameTick = 0;
int quantaPerTick = 500;
int gameState = STATE_ENDED;

int buttonLeftState = UP;
int buttonRightState = UP;

void addApple(void) {
	srand(steps);
	int x = rand() % 16;
	int y = rand() % 8;
	while (board[x][y] != 0) {
		x = rand() % 16;
		y = rand() % 8;
	}
	board[x][y] = APPLE;
}

void init_game(void) {
	for (int i = 0; i < 16; i++) {
		for (int j = 0; j < 8; j++) {
			board[i][j] = 0;
		}
	}
	snakeX = 4;
	snakeY = 4;
	snakeLength = 2;
	currDirection = RIGHT;
	nextDirection = RIGHT;
	
	board[snakeX][snakeY] = snakeLength;
	board[snakeX - 1][snakeY] = snakeLength - 1;
	
	addApple();
	gameTick = quantaPerTick;
	quantaPerTick = 500;
	gameState = STATE_RUNNING;
	redraw_board(board);
}

void PORTA_IRQHandler(void) {
	if (PORTA->ISFR & (1 << 4)) {
		// right button pressed
		RGBLED_GreenToggle();
		if (buttonRightState == UP) {
			buttonRightState = DOWN;
			if (gameState == STATE_RUNNING) {
				// update direction
				if (nextDirection != (currDirection + 1) % 4) {
					nextDirection = (nextDirection + 1) % 4;
				}
			} else {
				if (buttonLeftState == DOWN) {
					// restart game
					init_game();
				}
			}
		} else {
			buttonRightState = UP;
		}
		PORTA->ISFR = 1 << 4;
	}
}

void PORTC_IRQHandler(void) {
	if (PORTC->ISFR & (1 << 6)) {
		// left button pressed
		RGBLED_RedToggle();
		if (buttonLeftState == UP) {
			buttonLeftState = DOWN;
			if (gameState == STATE_RUNNING) {
				// update direction
				if (nextDirection != (currDirection + 3) % 4) {
					nextDirection = (nextDirection + 3) % 4;
				}
			}	else {
				if (buttonRightState == DOWN) {
					// restart game
					init_game();
				}
			}
		} else {
			buttonLeftState = UP;
		}
		PORTC->ISFR = 1 << 6;
	}
}
void PIT0_IRQHandler(void) {
	PIT->CHANNEL[0].TFLG = 1; // reset interrupt flag
	steps++;
	gameTick--;
	if (gameTick == 0) {
		gameTick = quantaPerTick;
		// do tick logic
		if (gameState == STATE_ENDED) {
			return;
		}
		int nX = snakeX;
		int nY = snakeY;
		switch (nextDirection) {
			case UP:
				nY++;
				break;
			case RIGHT:
				nX++;
				break;
			case DOWN:
				nY--;
				break;
			case LEFT:
				nX--;
				break;
		}
		currDirection = nextDirection;
		
		if (nX < 0 || nX >= 16 || nY < 0 || nY >= 8) {
			// hit edge of board
			gameState = STATE_ENDED;
			for (int i = 0; i < 16; i++) {
				for (int j = 0; j < 8; j++) {
					LED_matrix(i,j,LED_ON);
				}
			}
			redraw_matrix();
			return;
		}
		if (board[nX][nY] > 0) {
			// hit snake
			gameState = STATE_ENDED;
			for (int i = 0; i < 16; i++) {
				for (int j = 0; j < 8; j++) {
					LED_matrix(i,j,LED_ON);
				}
			}
			redraw_matrix();
			return;
		}
		
		if (board[nX][nY] == APPLE) {
			// hit apple
			snakeLength++;
			quantaPerTick -= 25;
			if (quantaPerTick < 50) {
				quantaPerTick = 50;
			}
			addApple();
		} else {
			// shrink snake
			for (int i = 0; i < 16; i++) {
				for (int j = 0; j < 8; j++) {
					if (board[i][j] > 0)
						board[i][j]--;
				}
			}
		}
		// move head
		board[nX][nY] = snakeLength;
		snakeX = nX;
		snakeY = nY;
		redraw_board(board);
	}

}

int main() {
	
	init_RGB_LEDS();
	init_LED_matrix();
	init_buttons();
	init_timer();
	init_game();
	
	
	while (TRUE);
}
