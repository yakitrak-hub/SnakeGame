#include <fsl_device_registers.h>
#include <stdint.h>
#include "fsl_i2c.h"

#ifndef UTIL_DEF
#define UTIL_DEF

#define TRUE (1==1)
#define FALSE (1==0)

uint32_t disable_interrupt(void);

void enable_interrupt(uint32_t m);

void init_RGB_LEDS(void);

void init_LED_matrix(void);

void init_buttons(void);

void init_timer(void);

void redraw_matrix(void);

void redraw_board(int8_t board[16][8]);

void RGBLED_Off (void);
void RGBLED_RedToggle(void);
void RGBLED_BlueToggle(void);
void RGBLED_GreenToggle(void);

#define LED_ON 1
#define LED_OFF 2
#define LED_TOGGLE 3

void LED_matrix(int x, int y, int state);

void delay(void);




#endif
